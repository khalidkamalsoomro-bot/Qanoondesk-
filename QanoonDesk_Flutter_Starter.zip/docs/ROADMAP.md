# QanoonDesk Roadmap

## Phase 1 — App skeleton
- [x] Main menu with individual icons
- [x] Home dashboard
- [x] Student Hub with LLB Years 1–5
- [x] Subjects and Notes/Past Papers/MCQs placeholders
- [x] Lawyer Desk sections
- [x] Law Library, AI Assistant, Saved Library, Settings placeholders

## Phase 2 — Build and test
- [ ] Install Flutter SDK and Android toolchain
- [ ] Create Android runner using `flutter create`
- [ ] Run on emulator or Android phone
- [ ] Test layouts, drawer selection, navigation and accessibility
- [ ] Generate debug APK

## Phase 3 — Data and backend
- [ ] Define content schemas
- [ ] Admin upload workflow
- [ ] Authentication and user profiles
- [ ] Secure file storage
- [ ] Save/bookmark functionality
- [ ] Local notifications

## Phase 4 — Populate content
- [ ] Verify common LLB subject structure
- [ ] Add notes gradually
- [ ] Add past papers with university/year labels
- [ ] Add MCQs and quizzes
- [ ] Add verified Pakistan legal materials with citations
