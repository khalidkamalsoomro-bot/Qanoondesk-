import 'package:flutter/material.dart';

void main() => runApp(const QanoonDeskApp());

const navy = Color(0xFF10243A);
const gold = Color(0xFFE3BD75);
const blue = Color(0xFF244D70);

class QanoonDeskApp extends StatelessWidget {
  const QanoonDeskApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'QanoonDesk',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: blue),
        scaffoldBackgroundColor: const Color(0xFFF5F7FA),
        appBarTheme: const AppBarTheme(
          backgroundColor: navy, foregroundColor: Colors.white,
          elevation: 0, centerTitle: false,
        ),
        useMaterial3: true,
      ),
      home: const MainShell(),
    );
  }
}

class MainShell extends StatefulWidget {
  const MainShell({super.key});
  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  String current = 'Home';
  String selectedYear = '1st Year';
  final years = const ['1st Year', '2nd Year', '3rd Year', '4th Year', '5th Year'];

  static const Map<String, List<String>> subjects = {
    '1st Year': ['Introduction to Law', 'English', 'Political Science', 'Sociology', 'Economics', 'Islamic Studies'],
    '2nd Year': ['Constitutional Law', 'Law of Contract', 'Criminal Law', 'Islamic Jurisprudence'],
    '3rd Year': ['Law of Torts', 'Property Law', 'Family Law', 'Jurisprudence'],
    '4th Year': ['Civil Procedure', 'Criminal Procedure', 'Evidence Law', 'Company Law'],
    '5th Year': ['Legal Ethics', 'Administrative Law', 'Labour Law', 'Advanced Legal Studies'],
  };

  void go(String page) {
    setState(() => current = page);
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('QanoonDesk', style: TextStyle(fontWeight: FontWeight.w700)),
        actions: [IconButton(onPressed: () => setState(() => current = 'My Library'),
          icon: const Icon(Icons.bookmark_border), tooltip: 'My Library')],
      ),
      drawer: _buildDrawer(),
      body: _buildPage(),
    );
  }

  Widget _buildDrawer() {
    return NavigationDrawer(
      selectedIndex: _drawerIndex(),
      onDestinationSelected: (index) {
        const destinations = ['Home', 'Student Hub', 'Lawyer Desk', 'Pakistan Law Library',
          'AI Legal Assistant', 'My Library', 'Profile & Settings', 'Help & Support'];
        setState(() => current = destinations[index]);
        Navigator.pop(context);
      },
      children: [
        Container(
          color: navy, padding: const EdgeInsets.fromLTRB(20, 30, 20, 22),
          child: const Row(children: [
            CircleAvatar(backgroundColor: gold, child: Icon(Icons.balance, color: navy, size: 28)),
            SizedBox(width: 12),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('QanoonDesk', style: TextStyle(color: Colors.white, fontSize: 21, fontWeight: FontWeight.bold)),
              SizedBox(height: 4),
              Text('Legal learning & practice', style: TextStyle(color: Color(0xFFD5DFE9))),
            ])),
          ]),
        ),
        const Padding(
          padding: EdgeInsets.fromLTRB(24, 16, 16, 8),
          child: Text('MAIN MENU', style: TextStyle(fontSize: 11, letterSpacing: 1.3, fontWeight: FontWeight.bold, color: Colors.blueGrey)),
        ),
        const NavigationDrawerDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: Text('Home')),
        const NavigationDrawerDestination(icon: Icon(Icons.school_outlined), selectedIcon: Icon(Icons.school), label: Text('Student Hub')),
        const NavigationDrawerDestination(icon: Icon(Icons.work_outline), selectedIcon: Icon(Icons.work), label: Text('Lawyer Desk')),
        const NavigationDrawerDestination(icon: Icon(Icons.account_balance_outlined), selectedIcon: Icon(Icons.account_balance), label: Text('Pakistan Law Library')),
        const NavigationDrawerDestination(icon: Icon(Icons.smart_toy_outlined), selectedIcon: Icon(Icons.smart_toy), label: Text('AI Legal Assistant')),
        const NavigationDrawerDestination(icon: Icon(Icons.bookmarks_outlined), selectedIcon: Icon(Icons.bookmarks), label: Text('My Library')),
        const Divider(indent: 20, endIndent: 20),
        const NavigationDrawerDestination(icon: Icon(Icons.settings_outlined), selectedIcon: Icon(Icons.settings), label: Text('Profile & Settings')),
        const NavigationDrawerDestination(icon: Icon(Icons.help_outline), selectedIcon: Icon(Icons.help), label: Text('Help & Support')),
      ],
    );
  }

  int _drawerIndex() {
    const destinations = ['Home', 'Student Hub', 'Lawyer Desk', 'Pakistan Law Library',
      'AI Legal Assistant', 'My Library', 'Profile & Settings', 'Help & Support'];
    final index = destinations.indexOf(current);
    return index < 0 ? 0 : index;
  }

  Widget _buildPage() {
    switch (current) {
      case 'Student Hub': return _studentHub();
      case 'Lawyer Desk': return _lawyerDesk();
      case 'Pakistan Law Library': return _placeholderPage('Pakistan Law Library', Icons.account_balance, 'Searchable legislation, rules and judgments will be added here.');
      case 'AI Legal Assistant': return _placeholderPage('AI Legal Assistant', Icons.smart_toy, 'Future source-grounded legal research and study assistance. AI answers must cite verifiable sources.');
      case 'My Library': return _placeholderPage('My Library', Icons.bookmarks, 'Saved notes, papers, laws and documents will appear here.');
      case 'Profile & Settings': return _placeholderPage('Profile & Settings', Icons.settings, 'Account, preferences, privacy and notifications.');
      case 'Help & Support': return _placeholderPage('Help & Support', Icons.help_outline, 'Help articles and contact options will be added here.');
      default: return _home();
    }
  }

  Widget _home() => ListView(padding: const EdgeInsets.all(16), children: [
    Container(
      padding: const EdgeInsets.all(20), decoration: BoxDecoration(color: navy, borderRadius: BorderRadius.circular(20)),
      child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('YOUR LEGAL WORKSPACE', style: TextStyle(color: gold, fontSize: 11, letterSpacing: 1.4, fontWeight: FontWeight.bold)),
        SizedBox(height: 12),
        Text('Learn law. Practice law.', style: TextStyle(color: Colors.white, fontSize: 25, fontWeight: FontWeight.bold)),
        SizedBox(height: 8),
        Text('One platform for law students and legal professionals in Pakistan.', style: TextStyle(color: Color(0xFFD5DFE9), height: 1.4)),
      ]),
    ),
    const SizedBox(height: 20),
    const Text('Choose your workspace', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
    const SizedBox(height: 12),
    _homeCard('Student Hub', 'LLB Years 1–5, notes, subjects and past papers', Icons.school_outlined, () => setState(() => current = 'Student Hub')),
    _homeCard('Lawyer Desk', 'Research, drafting, matters and hearing reminders', Icons.work_outline, () => setState(() => current = 'Lawyer Desk')),
    _homeCard('Pakistan Law Library', 'Browse legislation and legal authorities', Icons.account_balance_outlined, () => setState(() => current = 'Pakistan Law Library')),
    _homeCard('AI Legal Assistant', 'Future source-grounded legal assistance', Icons.smart_toy_outlined, () => setState(() => current = 'AI Legal Assistant')),
    const SizedBox(height: 12),
    const Text('Starter version · Sample structure only', style: TextStyle(color: Colors.blueGrey, fontSize: 12)),
  ]);

  Widget _homeCard(String title, String subtitle, IconData icon, VoidCallback onTap) => Card(
    margin: const EdgeInsets.only(bottom: 10), elevation: 0, child: ListTile(
      contentPadding: const EdgeInsets.all(12), leading: CircleAvatar(backgroundColor: const Color(0xFFE8EEF5), child: Icon(icon, color: blue)),
      title: Text(title, style: const TextStyle(fontWeight: FontWeight.w700)),
      subtitle: Padding(padding: const EdgeInsets.only(top: 5), child: Text(subtitle)),
      trailing: const Icon(Icons.chevron_right), onTap: onTap,
    ),
  );

  Widget _studentHub() => ListView(padding: const EdgeInsets.all(16), children: [
    const Text('LLB Study Hub', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
    const SizedBox(height: 6),
    const Text('A common study library for LLB students across Pakistan.', style: TextStyle(color: Colors.blueGrey)),
    const SizedBox(height: 18),
    Wrap(spacing: 8, runSpacing: 8, children: years.map((year) => ChoiceChip(
      label: Text(year), selected: selectedYear == year, onSelected: (_) => setState(() => selectedYear = year),
    )).toList()),
    const SizedBox(height: 18),
    Text(selectedYear, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
    const SizedBox(height: 8),
    ...subjects[selectedYear]!.map((subject) => Card(
      elevation: 0, child: ListTile(leading: const Icon(Icons.menu_book_outlined, color: blue),
        title: Text(subject), subtitle: const Text('Subject workspace'), trailing: const Icon(Icons.chevron_right),
        onTap: () => showModalBottomSheet(context: context, builder: (_) => SafeArea(child: Padding(
          padding: const EdgeInsets.all(24), child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(subject, style: const TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            _resourceRow(Icons.notes, 'Notes', 'Topic-wise study notes'),
            _resourceRow(Icons.description_outlined, 'Past Papers', 'Past examination papers'),
            _resourceRow(Icons.quiz_outlined, 'MCQs & Quizzes', 'Practice and revision'),
            const SizedBox(height: 12),
            const Text('Sample structure. Content will be added later.', style: TextStyle(color: Colors.blueGrey)),
          ]),
        ))),
      ),
    )),
    const SizedBox(height: 12),
    const Text('Note: Subject lists are illustrative and must be reviewed before release.', style: TextStyle(color: Colors.blueGrey, fontSize: 12)),
  ]);

  Widget _resourceRow(IconData icon, String title, String subtitle) => ListTile(
    contentPadding: EdgeInsets.zero, leading: Icon(icon, color: blue), title: Text(title), subtitle: Text(subtitle),
    onTap: () => Navigator.pop(context),
  );

  Widget _lawyerDesk() => ListView(padding: const EdgeInsets.all(16), children: [
    const Text('Lawyer Desk', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
    const SizedBox(height: 6),
    const Text('Tools for legal practice in Pakistan.', style: TextStyle(color: Colors.blueGrey)),
    const SizedBox(height: 16),
    _homeCard('Legal Research', 'Legislation, sections and judgments', Icons.search, () => _showInfo('Legal Research', 'Connect a verified legal database before release.')),
    _homeCard('Draft Templates', 'Notices, applications and legal documents', Icons.edit_document, () => _showInfo('Draft Templates', 'Verified templates will be added later.')),
    _homeCard('My Cases', 'Organize matters and case documents', Icons.folder_open, () => _showInfo('My Cases', 'Case storage and privacy controls require backend implementation.')),
    _homeCard('Hearings & Tasks', 'Dates, tasks and reminders', Icons.calendar_month, () => _showInfo('Hearings & Tasks', 'Calendar and notifications will be implemented in a later phase.')),
  ]);

  Widget _placeholderPage(String title, IconData icon, String message) => ListView(padding: const EdgeInsets.all(20), children: [
    CircleAvatar(radius: 32, backgroundColor: const Color(0xFFE8EEF5), child: Icon(icon, color: blue, size: 32)),
    const SizedBox(height: 18), Text(title, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
    const SizedBox(height: 8), Text(message, style: const TextStyle(height: 1.5, color: Colors.blueGrey)),
    const SizedBox(height: 18), const Card(child: Padding(padding: EdgeInsets.all(16), child: Text('This section is part of the app structure. Features and real content will be connected gradually.'))),
  ]);

  void _showInfo(String title, String message) {
    showDialog(context: context, builder: (_) => AlertDialog(title: Text(title), content: Text(message),
      actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('OK'))]));
  }
}
