# QanoonDesk — Flutter starter

A starter Flutter Android project structure for a Pakistan-focused legal platform.

## What is included
- Home screen and navigation drawer
- Student Hub with LLB Years 1–5
- Subject, Notes, Past Papers and MCQ placeholders
- Lawyer Desk sections for research, drafts, matters and hearings
- Pakistan Law Library placeholder
- AI Legal Assistant placeholder
- Saved Library and Settings screens
- Sample content only; no legal materials or live backend are included

## Run
1. Install Flutter SDK and Android Studio.
2. Run `flutter create qanoondesk` in a separate directory, or use this `lib/` and `pubspec.yaml` in a new Flutter project.
3. Replace the generated `lib/main.dart` with this project's `lib/main.dart`.
4. Run `flutter pub get`
5. Run `flutter run`

This source has not been compiled into an APK in this environment. Flutter SDK/Android build tooling is required to build and test the app.
